# Audit Logger

Single-admin compatible marketplace acceptance package.

This local build must be uploaded to the hosted marketplace artifact URL before external marketplace acceptance can pass.
