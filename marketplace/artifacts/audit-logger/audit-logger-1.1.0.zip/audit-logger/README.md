# Audit Logger

Single-admin compatible marketplace acceptance package.

This local build must be served from the hosted marketplace artifact URL before external marketplace acceptance can pass.
