"""Audit logger marketplace acceptance package."""

VALUE = 1
